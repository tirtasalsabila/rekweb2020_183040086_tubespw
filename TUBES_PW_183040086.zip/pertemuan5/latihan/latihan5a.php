<?php
$a = "";
if(isset($_GET["nomer"])){
		$a = $_GET["nomer"];
}
	 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Latihan 5a</title>
	<style type="text/css">
		.clear {
			clear: both;
		}

		.kotak1 {
			background : aqua;
			height: 20px;
			width: 20px;
			text-align: center;
			border: 1px solid black;
			margin:2px;
			display: inline-block;
		}

	
	.kotak2{
			height: 20px;
			width: 20px;
			border: 1px solid black;
			text-align: center;
			margin:2px;
			display: inline-block;
		}

	</style>
</head>
<body>
<?php 	
		for($i =$a; $i >= 1; $i-- ){
			for($j = $i; $j >= 	1; $j--){
				if($i % 2 == 1 ) {
					echo "<div class ='kotak2 clear'>$i</div>";
				}
				else {
						echo "<div class ='kotak1 clear'>$i</div>";
				}
			}
			echo "<br>";
		}
 ?>

</body>
</html>