<?php 
	$e = [
			["No" => "1",
			 "Judul" => "The Good Girl",
			 "Gambar" => "a.jpg",
			 "Penulis" => "Mary Kubica",
			 "Tahun" => "2019",
			 "Genre" => "Mystery"],

			 ["No" => "2",
			 "Judul" => "The Black Rose",
			 "Gambar" => "b.jpg",
			 "Penulis" => "Daysen",
			 "Tahun" => "2019",
			 "Genre" => "Mystery"],

			 ["No" => "3",
			 "Judul" => "Peti Tertutup",
			 "Gambar" => "c.jpg",
			 "Penulis" => "Sophie Hannah",
			 "Tahun" => "2019",
			 "Genre" => "Mystery"],

			 ["No" => "4",
			 "Judul" => "Rahasia Ke-13",
			 "Gambar" => "d.jpg",
			 "Penulis" => "Shirley Du",
			 "Tahun" => "2019",
			 "Genre" => "Thriller, Mystery"],

			 ["No" => "5",
			 "Judul" => "Misteri Gua Rahasia",
			 "Gambar" => "e.jpg",
			 "Penulis" => "Hanna Christina",
			 "Tahun" => "2019",
			 "Genre" => "Mystery"],

			 ["No" => "6",
			 "Judul" => "Anak Teladan",
			 "Gambar" => "f.jpg",
			 "Penulis" => "Jeong You-Jeong",
			 "Tahun" => "2019",
			 "Genre" => "Mystery"],

			 ["No" => "7",
			 "Judul" => "Misteri Tiga Perempat",
			 "Gambar" => "g.jpg",
			 "Penulis" => "Sophie Hannah",
			 "Tahun" => "2019",
			 "Genre" => "Mystery"],

			 ["No" => "8",
			 "Judul" => "Misteri Sepasang Hati",
			 "Gambar" => "h.jpg",
			 "Penulis" => "V Lestari",
			 "Tahun" => "2019",
			 "Genre" => "Mystery, Romance"],

			 ["No" => "9",
			 "Judul" => "Kartu-kartu di Meja",
			 "Gambar" => "i.jpg",
			 "Penulis" => "Agatha Christie",
			 "Tahun" => "2019",
			 "Genre" => "Suspense"],

			 ["No" => "10",
			 "Judul" => "Parfume",
			 "Gambar" => "j.jpg",
			 "Penulis" => "Patrick Suskind",
			 "Tahun" => "2019",
			 "Genre" => "Mystery"],
	];




 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Latihan 5b</title>
</head>
<body>
				<?php foreach ($e as $alat) : ?>
						<li><a href="latihan5c.php?Judul=<?= $alat["Judul"]; ?>&Gambar=<?= $alat["Gambar"]; ?>&Penulis=<?= $alat["Penulis"]; ?>&Tahun=<?= $alat["Penulis"]; ?>&Tahun=<?= $alat["Tahun"]; ?>&Genre=<?= $alat["Genre"]; ?>&No=<?= $alat["No"]; ?>"><?= $alat["Judul"]; ?></a></li>
				<?php endforeach ; ?>
</table>
</body>
</html>
