
<?php
require 'function.php';
$buku = query("SELECT * FROM buku");

 ?>


<!DOCTYPE html>
<html>
<head>
	<title>Latihan 6c</title>
</head>
<body>
<?php foreach($buku as $book) :?>
	<li><a href="profil.php?Judul=<?= $book["Judul"]; ?>&Gambar=<?= $book["Gambar"]; ?>&Penulis=<?= $book["Penulis"]; ?>&Tahun=<?= $book["Penulis"]; ?>&Tahun=<?= $book["Tahun"]; ?>&Genre=<?= $book["Genre"]; ?>&No=<?= $book["No"]; ?>"><?= $book["Judul"]; ?></a></li>
<?php endforeach; ?>

</body>
</html>	