<?php 
if( !isset($_GET["Judul"])){
	header("Location:index.php");
	exit;
}
require 'function.php';	

 ?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.gambar {
			width: 300px;
			height: 450px;
		}
	</style>
</head>
<body>

	<table border="1" cellspacing="0" cellpadding="10">
			<tr>
				<th>No</th>
				<th>Judul Buku</th>
				<th>Gambar</th>
				<th>Penulis</th>
				<th>Tahun Rilis</th>
				<th>Genre</th>
			</tr>
			<tr>
				
			<td align="center"><?= $_GET["No"]; ?></td>
 			<td><?= $_GET["Judul"]; ?></td>
 			<td><img class="gambar" src="../../../im/<?= $_GET["Gambar"]; ?>"></td>
 			<td><?= $_GET["Penulis"]; ?></td>
 			<td><?= $_GET["Tahun"]; ?></td>
 			<td><?= $_GET["Genre"]; ?></td>
			</tr>
</table>

</body>
</html>