
<?php 	
require 'function.php';
$buku = query("SELECT * From buku");

 ?>


<!DOCTYPE html>
<html>
<head>
	<title>Latihan 6b</title>
		<style>
		.gambar {
			width: 300px;
			height: 450px;
		}
	</style>
</head>
<body>

<table border="1" cellspacing="0" cellpadding="10">
			<tr>
				<th>No</th>
				<th>Judul Buku</th>
				<th>Gambar</th>
				<th>Penulis</th>
				<th>Tahun Rilis</th>
				<th>Genre</th>
			</tr>
			<tr>
				<?php foreach($buku as $nama) : ?>
			<td align="center"><?= $nama["No"]; ?></td>
 			<td><?= $nama["Judul"]; ?>	</td>
 			<td><img class="gambar" src="../../../im/<?= $nama["Gambar"]; ?>"></td>
 			<td><?= $nama["Penulis"]; ?></td>
 			<td><?= $nama["Tahun"]; ?></td>
 			<td><?= $nama["Genre"]; ?></td>
			</tr>
		<?php endforeach; ?>
</table>
</body>
</html>