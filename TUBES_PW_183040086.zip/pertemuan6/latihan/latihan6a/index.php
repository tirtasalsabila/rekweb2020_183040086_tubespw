
<?php 	
$conn = mysqli_connect("localhost","root","") or die ("Koneksi ke DB gagal !");
mysqli_select_db($conn,"pw_183040086") or die ("Databse SALAH!!");
$result= mysqli_query($conn, "SELECT * FROM buku");
 ?>


<!DOCTYPE html>
<html>
<head>
	<title>Latihan 6a</title>
	<style type="text/css">
				.gambar {
			width: 300px;
			height: 450px;
		}
	</style>
</head>
<body>

<table border="1" cellspacing="0" cellpadding="10">
			<tr>
				<th>No</th>
				<th>Judul Buku</th>
				<th>Gambar</th>
				<th>Penulis</th>
				<th>Tahun Rilis</th>
				<th>Genre</th>
			</tr>
			<tr>
				<?php while($row=mysqli_fetch_assoc($result)): ?>
			<td align="center"><?= $row["No"]; ?></td>
 			<td><?= $row["Judul"]; ?></td>
 			<td><img class="gambar" src="../../../im/<?= $row["Gambar"]; ?>"></td>
 			<td><?= $row["Penulis"]; ?></td>
 			<td><?= $row["Tahun"]; ?></td>
 			<td><?= $row["Genre"]; ?></td>
			</tr>
		<?php 	endwhile; ?>
</table>
</body>
</html>