<?php 	
if( isset($_POST["submit"])){
	if ($_POST["username"] == "admin" && $_POST["password"] == "admin"){
		header("Location: admin.php");
		exit;
	} else {
		$error = true;
	}

}

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Latihan5e</title>
	<style type="">
		.container{
	width: 280px;
	height: 280px;
	background-color: lightblue;
	margin: 0 auto;
	position: relative;
	text-align: center;
}
		.img {
			width: 100px;
		}
	</style>
</head>
<body>
	<p>username : admin</p>
	<p>password : admin</p>
	<p>selain itu salah!!</p>
	<div class="container">
<form action="" method="post">	
<h2>Login admin</h2>

<?php if( isset($error)) : ?>
	<p style="color: red"> Username/Password anda Salah</p>
	<?php endif; ?>

<img src="../../im/user.png" class="img">
<br>	
<br>	
<label for="username">Username:</label>
<input type="text" name="username" id="username">
<br>
<label for="password">Password:</label>
<input type="password" name="password" id="password">
<br>
<br>
<button type="submit" name="submit">Login</button>

</form>

</div>


</body>
</html>