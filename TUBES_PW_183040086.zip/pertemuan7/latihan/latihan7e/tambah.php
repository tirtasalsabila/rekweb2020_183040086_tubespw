<?php 	

require 'function.php';

if( isset($_POST["submit"]) ) {
	
	if( tambah($_POST) > 0 ) {
		echo "
			<script>
				alert('data berhasil ditambahkan!');
				document.location.href = 'index.php';
			</script>
		";
	} else {
		echo "
			<script>
				alert('data gagal ditambahkan!');
				document.location.href = 'index.php';
			</script>
		";
	}


}

 ?>








<!DOCTYPE html>
<html>
<head>
	<title>Tambah Data Baru</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
<form action="" method="post">
	<ul>
		<li>
			<label for="No">No :</label>
			<input type="text" name="No" id="No">
		</li>
		<li>
			<label for="Judul">Judul :</label>
			<input type="text" name="Judul" id="Judul">
		</li>
		<li>
			<label for="Gambar">Gambar :</label>
			<input type="text" name="Gambar" id="Gambar">
		</li>
		<li>
			<label for="Penulis">Penulis :</label>
			<input type="text" name="Penulis" id="Penulis">
		</li>
		<li>
			<label for="Tahun">Tahun :</label>
			<input type="text" name="Tahun" id="Tahun">
		</li>
		<li>
			<label for="Genre">Genre :</label>
			<input type="text" name="Genre" id="Genre">
		</li>
	</ul>

<button class="btn waves-effect waves-light" type="submit" name="submit">Submit
    <i class="material-icons right">send</i>
  </button>




</form>



    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>