
<?php 	
require 'function.php';
$buku = query("SELECT * From buku");

 ?>


<!DOCTYPE html>
<html>
<head>
	<title>Latihan 7b</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<style>
		.gambar {
			width: 300px;
			height: 450px;
		}

	</style>
</head>
<body>

<table border="1" cellspacing="0" cellpadding="10">

	<a href="tambah.php" class="waves-effect waves-light btn card-panel teal-lig">Tambah Data Baru</a>
	<br>
			<tr class="card-panel teal lig">
				<th>No</th>
				<th>Opsi</th>
				<th>Judul Buku</th>
				<th>Gambar</th>
				<th>Penulis</th>
				<th>Tahun Rilis</th>
				<th>Genre</th>
			</tr>
			<tr>
				<?php foreach($buku as $nama) : ?>
			<td align="center"><?= $nama["No"]; ?></td>
					<td>	
							<a class="waves-effect waves-light btn">Ubah</a>
							<a class="waves-effect waves-light btn red">Hapus</a>

					</td>
 			<td><?= $nama["Judul"]; ?></td>
 			<td><img class="gambar" src="../../../im/<?= $nama["Gambar"]; ?>	"></td>
 			<td><?= $nama["Penulis"]; ?></td>
 			<td><?= $nama["Tahun"]; ?></td>
 			<td><?= $nama["Genre"]; ?></td>
			</tr>
		<?php endforeach; ?>
</table>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>