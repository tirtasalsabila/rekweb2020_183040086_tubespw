<?php
$conn = mysqli_connect("localhost", "root", "", "pw_183040086");


function query($query) {
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while( $row = mysqli_fetch_assoc($result) ) {
		$rows[] = $row;
	}
	return $rows;
}
function tambah($data) {
	global $conn;

	$No = htmlspecialchars($data["No"]);
	$Judul = htmlspecialchars($data["Judul"]);
	$Gambar = htmlspecialchars($data["Gambar"]);
	$Penulis = htmlspecialchars($data["Penulis"]);
	$Tahun = htmlspecialchars($data["Tahun"]);
	$Genre = htmlspecialchars($data["Genre"]);

	$query = "INSERT INTO buku
				VALUES
			  ('$No', '$Judul', '$Gambar', '$Penulis', '$Tahun','$Genre')
			";
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}


?>