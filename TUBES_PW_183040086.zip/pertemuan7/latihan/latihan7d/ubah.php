<?php
require 'function.php';

$No = $_GET["No"];
$buku = query("SELECT * FROM buku WHERE No = $No")[0];


// cek apakah tombol submit sudah ditekan atau belum
if( isset($_POST["submit"]) ) {
	
	// cek apakah data berhasil diubah atau tidak
	if( ubah($_POST) > 0 ) {
		echo "
			<script>
				alert('data berhasil diubah!');
				document.location.href = 'index.php';
			</script>
		";
	} else {
		echo "
			<script>
				alert('data gagal diubah!');
				document.location.href = 'index.php';
			</script>
		";
	}


}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Ubah data</title>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
	<h1>Ubah data buku</h1>

	<form action="" method="post">
		<input type="hidden" name="No" value="<?= $buku["No"]; ?>">
		<ul>
			<li>
				<label for="Judul">Judul : </label>
				<input type="text" name="Judul" id="Judul" required value="<?= $buku["Judul"]; ?>">
			</li>
			<li>
				<label for="Gambar">Gambar : </label>
				<input type="text" name="Gambar" id="Gambar" value="<?= $buku["Gambar"]; ?>">
			</li>
			<li>
				<label for="Penulis">Penulis :</label>
				<input type="text" name="Penulis" id="Penulis" value="<?= $buku["Penulis"]; ?>">
			</li>
			<li>
				<label for="Tahun">Tahun :</label>
				<input type="text" name="Tahun" id="Tahun" value="<?= $buku["Tahun"]; ?>">
			</li>
			<li>
				<label for="Genre">Genre :</label>
				<input type="text" name="Genre" id="Genre" value="<?= $buku["Genre"]; ?>">
			</li>
			<li>
				<button class="btn waves-effect waves-light" type="submit" name="submit">ubah	
    			<i class="material-icons right">all_inclusive</i>
  				</button>
			</li>
		</ul>

	</form>



    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>